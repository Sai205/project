import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-entry',
  templateUrl: './product-entry.component.html',
  styleUrls: ['./product-entry.component.css']
})
export class ProductEntryComponent implements OnInit {

  formData: any = {};
  constructor() { }

  ngOnInit(): void {
  }

  register(): void {
    console.log(this.formData);
  }
}
