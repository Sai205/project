import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentComponent } from './department/department.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { DetailsComponent } from './details/details.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { ViewOrderComponent } from './view-order/view-order.component';

const routes: Routes =[
  {path: 'department', component: DepartmentComponent},
  {path: 'employees', component: EmployeeListComponent},
  {
    path:'details',
    component:DetailsComponent
  },
  {
    path:'addtocart',
    component:AddToCartComponent
  }
   ];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[EmployeeListComponent,DepartmentComponent]