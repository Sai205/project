import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent implements OnInit {

  products=[
    {
      "name":"Azithral",
      "price":"119"
    },
    {
      "name":"augmentin 625",
      "price":"225.25"
    }, {
      "name":"ascoril syrup",
      "price":"108"
    },
    {
      "name":"Azee",
      "price":"110"
    },
    {
      "name":"Alex syrup",
      "price":"117"
    }
  ]

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  getNavigation(){
this.route.navigateByUrl('/details');
  }
  // deleteProduct(){}
}
