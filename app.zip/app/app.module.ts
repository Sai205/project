import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule , routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductEntryComponent } from './product-entry/product-entry.component';
import { ViewOrderComponent } from './view-order/view-order.component';
import { AddToCartComponent } from './add-to-cart/add-to-cart.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { PayComponent } from './pay/pay.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { RegisterComponent } from './register/register.component';
import { ProfileComponent } from './profile/profile.component';
import { LoginComponent } from './login/login.component';
import { DetailsComponent } from './details/details.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LogoutComponent } from './logout/logout.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductEntryComponent,
    ViewOrderComponent,
    ViewDetailsComponent,
    LoginComponent,
    UserProfileComponent,
    RegisterComponent,
    DetailsComponent,
    ProfileComponent,
    AddToCartComponent,
    PayComponent,
    routingComponents,
    FooterComponent,
    HeaderComponent,
    LogoutComponent
        ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
