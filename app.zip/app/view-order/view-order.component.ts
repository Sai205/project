import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.component.html',
  styleUrls: ['./view-order.component.css']
})
export class ViewOrderComponent implements OnInit {

  itemsarray=[
    {
      "id":1,
      "name":"Azithral",
      "price":"195",
      "companyname":"Alembic pharma ltd",
      "order":"27-jan-22",
      "ddate":"28-jan-22"
    },
    {
      "id":2,
      "name":"Augmentin",
      "price":"625",
      "companyname":"galaxi pharma ltd",
      "order":"27-jan-22",
      "ddate":"28-jan-22"
    },
    {
      "id":3,
      "name":"Ascoril ls syrup",
      "price":"108",
      "companyname":"Gelnmark pharma ltd",
      "order":"27-jan-22",
      "ddate":"28-jan-22"
    },
    {
      "id":4,
      "name":"Azee",
      "price":"500",
      "companyname":"clipa ltd",
      "order":"27-jan-22",
      "ddate":"28-jan-22"
    },
    {
      "id":5,
      "name":"alex syrup",
      "price":"120",
      "companyname":"gelnmark pvt ltd",
      "order":"27-jan-22",
      "ddate":"28-jan-22"
    }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
